const express = require('express');
const cors = require('cors'); // Importa el paquete cors

const respuesta = require('../../red/respuesta')
const controlador = require('./controlador');

const router = express.Router();

router.get('/', todos);
router.get('/:id', uno);
router.get('/', agregar);

async function todos (req, res, next) {
    try{
        const items = await controlador.todos(req.params.id)
        respuesta.success(req,res, items, 200);
    }catch(err){
        next(err);
    }
    };

async function uno (req, res, next) {
    try{
        const items = await controlador.uno(req.params.id)
        respuesta.success(req,res, items, 200);
    }catch(err){
        next(err);
    }
    };

async function agregar (req, res, next) {
    try{
        const items = await controlador.agregar(req.params.id)
        if(req.body.id == 0){
            mensaje = 'Item guardado exitosamente';
        }else{
            mensaje = 'Item actualizado exitosamente';
        }
        respuesta.success(req,res, mensaje, 201);
    }catch(err){
        next(err);
    }
    };


module.exports = router;