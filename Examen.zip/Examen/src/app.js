const express = require('express');
const morgan = require('morgan');
const config = require('./config');
const cors = require('cors'); // Importa el paquete cors

const prospectos = require('./Modulos/prospectos/rutas');
const error = require('./red/errors');

const app = express();

app.use(cors({
    origin: 'http://localhost:8080', // Origen permitido
    methods: 'GET,POST', // Métodos permitidos
    allowedHeaders: 'Content-Type,Authorization', // Cabeceras permitidas
  }));
app.use(morgan('dev'));
app.use(express.json());
app.use(express.urlencoded({extended: true}));

app.set('port', config.app.port)

app.use('/api/prospectos', prospectos)
app.use(error);

module.exports = app;