const app = require('./app');
const cors = require('cors'); // Importa el paquete cors

app.use(cors({
    origin: 'http://localhost:8080', // Origen permitido
    methods: 'GET,POST', // Métodos permitidos
    allowedHeaders: 'Content-Type,Authorization', // Cabeceras permitidas
  }));

app.listen(app.get('port'), () => {
    console.log("Servidor en el puerto", app.get("port"));
});