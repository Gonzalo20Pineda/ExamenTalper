const mysql = require('mysql');
const config = require('../config');
const { error } = require('../red/respuesta');
const cors = require('cors'); // Importa el paquete cors

const dbconfig = {
    host: config.mysql.host,
    user: config.mysql.user,
    password: config.mysql.password,
    database: config.mysql.database,
}

let conexion;

function conMysql(){
    conexion = mysql.createConnection(dbconfig);

    conexion.connect((err) => {
        if(err){
            console.log('[db err]', err);
            setTimeout(conMysql, 200);
        }else{
            console.log('DB Conectada')
        }
    });

    conexion.on('error', err => {
        console.log('[db err]', err);
        if(err.code === 'PROTOCOL_CONNECTION_LOST'){
            conMysql();
        }else{
            throw err;
        }
    })
}

conMysql();

function todos(tabla){
    return new Promise( (resolve, reject) =>{
        conexion.query(`select * from ${tabla}`, (error, result) => {
            return error ? reject(error) : resolve(result);
        })
    });
}

function uno(tabla, id){
    return new Promise( (resolve, reject) =>{
        conexion.query(`select * from ${tabla} where id= ${id}`, (error, result) => {
            return error ? reject(error) : resolve(result);
        })
    });
}

function insertar(tabla, id){
    return new Promise( (resolve, reject) =>{
        conexion.query(`insert into ${tabla} set ?`, data, (error, result) => {
            return error ? reject(error) : resolve(result);
        })
    });
}

function actualizar(tabla, id){
    return new Promise( (resolve, reject) =>{
        conexion.query(`update ${tabla} set ? where id = ?`,[data, data.id], (error, result) => {
            return error ? reject(error) : resolve(result);
        })
    });
}

function agregar(tabla, data){
    if(data && data.id == 0){
        return insertar(tabla, data);
    }else{
        return actualizar(tabla, data);
    }
}

module.exports = {
    todos,
    uno,
    agregar,
    actualizar,
}